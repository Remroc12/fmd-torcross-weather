FMD Torcross weather dashboard - branded update

Upload BOTH files into the GitHub repository's public/ folder:
- index.html (replace existing public/index.html if necessary)
- fmd-logo.png (new image)

The HTML already references /fmd-logo.png in its header.
No API key belongs in these public files.
